﻿Imports System.IO
Imports System.Security.Cryptography
Public Class Form1
    Private Sub btnScan_Click(sender As Object, e As EventArgs) Handles btnScan.Click
        Dim fbd As New FolderBrowserDialog

        If fbd.ShowDialog = DialogResult.OK Then

            btnScan.Enabled = False
            btnDelete.Enabled = False
            btnClear.Enabled = False

            System.Threading.ThreadPool.QueueUserWorkItem(Sub() scan_dir(fbd.SelectedPath))
        End If
    End Sub

    Private Sub scan_dir(folderPath As String)
        CheckForIllegalCrossThreadCalls = False

        DataGridView1.ScrollBars = DataGridView1.ScrollBars.None

        Dim fileHashes As New Dictionary(Of String, List(Of String))()

        Dim allFiles As String() = Directory.GetFiles(folderPath, "*.*", SearchOption.AllDirectories)

        For Each file In allFiles
            Dim fileHash As String = GetFileMD5(file)

            If fileHashes.ContainsKey(fileHash) Then
                fileHashes(fileHash).Add(file)
            Else
                fileHashes.Add(fileHash, New List(Of String) From {file})
            End If
        Next

        DataGridView1.Rows.Clear()
        For Each hashPair In fileHashes
            If hashPair.Value.Count > 1 Then
                For Each filePath In hashPair.Value
                    DataGridView1.Rows.Add(False, Path.GetFileName(filePath), filePath)
                Next
            End If
        Next

        DataGridView1.ScrollBars = DataGridView1.ScrollBars.Both

        btnScan.Enabled = True
        btnDelete.Enabled = True
        btnClear.Enabled = True
    End Sub

    Private Function GetFileMD5(filePath As String) As String
        Using md5 As MD5 = MD5.Create()
            Using stream As FileStream = File.OpenRead(filePath)
                Dim hashBytes As Byte() = md5.ComputeHash(stream)
                Return BitConverter.ToString(hashBytes).Replace("-", "").ToLowerInvariant()
            End Using
        End Using
    End Function

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        DataGridView1.Rows.Clear()
    End Sub

    Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click

        btnScan.Enabled = False
        btnDelete.Enabled = False
        btnClear.Enabled = False

        System.Threading.ThreadPool.QueueUserWorkItem(Sub() delete_dups())
    End Sub

    Private Sub delete_dups()
        CheckForIllegalCrossThreadCalls = False

        For Each row As DataGridViewRow In DataGridView1.Rows

            If row.IsNewRow Then Continue For


            If Convert.ToBoolean(row.Cells(0).Value) Then

                Dim filePath As String = row.Cells("colPath").Value.ToString()

                If System.IO.File.Exists(filePath) Then
                    Try
                        System.IO.File.Delete(filePath)
                    Catch : End Try
                End If
            End If
        Next

        btnScan.Enabled = True
        btnDelete.Enabled = True
        btnClear.Enabled = True

        DataGridView1.Rows.Clear()

        MessageBox.Show("Duplicated removed!", "Done.")
    End Sub

    Private Sub CheckBox1_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox1.CheckedChanged
        btnScan.Enabled = False
        btnDelete.Enabled = False
        btnClear.Enabled = False

        CheckBox1.Checked = False

        System.Threading.ThreadPool.QueueUserWorkItem(Sub() uncheck_all())
    End Sub

    Private Sub uncheck_all()
        CheckForIllegalCrossThreadCalls = False

        For Each row As DataGridViewRow In DataGridView1.Rows
            If Not row.IsNewRow Then
                row.Cells(0).Value = False
            End If
        Next

        btnScan.Enabled = True
        btnDelete.Enabled = True
        btnClear.Enabled = True
    End Sub
End Class
